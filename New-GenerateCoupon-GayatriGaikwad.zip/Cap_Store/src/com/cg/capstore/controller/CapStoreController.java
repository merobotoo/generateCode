package com.cg.capstore.controller;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capstore.dto.Coupon;
import com.cg.capstore.service.ICapstoreService;


@Controller
public class CapStoreController 
{
	@Autowired
	ICapstoreService capstoreService;

	@RequestMapping("all")
	public String generateCoupon(Model model)
	{
		return "generatebutton";
	}
	@RequestMapping("generate")
	public String couponlist(Model model)
	{  
		
		/*List<Coupon> myAllData=capSService.getAllCoupons();
		model.addAttribute("List",myAllData);*/
		
		System.out.println("hello");
		String output = "";
			char c=0;
			int j=10;
		    char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
		    int amount=1;

		    Random random = new Random();
		    List <Coupon> coup = null;
		    while(j!=0)
		    {
		        	StringBuilder sb = new StringBuilder();
		        	for (int i = 0; i < 8; i++)
		        	{
			        	c = chars[random.nextInt(chars.length)];
			        	sb.append(c);


			        }
		        	amount = j*100;
		        	output = sb.toString();
		        	j--;
		        	System.out.println(output + " " +amount);
		        	Coupon coupon = new Coupon();
		        	coupon.setCouponCode(output);
		        	coupon.setCouponAmount(amount);
		        	capstoreService.insertdata(coupon);
		        	
		    }
		    
		    List<Coupon> myAllData=capstoreService.getAllCoupons();
			model.addAttribute("List",myAllData);
		return "home";
	}

}
