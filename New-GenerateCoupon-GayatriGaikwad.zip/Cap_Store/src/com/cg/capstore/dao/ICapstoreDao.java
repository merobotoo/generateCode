package com.cg.capstore.dao;

import java.util.List;

import com.cg.capstore.dto.Coupon;

public interface ICapstoreDao 
{
	public void insertdata(Coupon coupon);
	public List<Coupon> getAllCoupons();
}
