package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Coupon;



@Repository("capstoreDao")
public class CapStoreDaoImpl implements ICapstoreDao {
	
	@PersistenceContext
	EntityManager em;


	@Override
	public List<Coupon> getAllCoupons() 
	{
		TypedQuery<Coupon> query= (TypedQuery<Coupon>) em.createQuery("From Coupon");
		return query.getResultList();
	}

	@Override
	public void insertdata(Coupon coupon) {
		// TODO Auto-generated method stub
		em.persist(coupon);
		em.flush();
		
	}

}
